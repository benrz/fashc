<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"> -->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome-animation/0.0.8/font-awesome-animation.min.css">


<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/bootstrap.min.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/magnific-popup.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/animate.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/owl.carousel.min.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/themify-icons.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/pe-icon-7-stroke.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/icofont.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/meanmenu.min.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/bundle.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/style.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/responsive.css'); ?>">
