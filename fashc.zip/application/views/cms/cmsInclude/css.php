<!-- Data Tables -->
<link rel="stylesheet" href="<?php echo base_url('assets/cms_assets/datatables/css/dataTables.bootstrap.min.css'); ?>">

<!-- Bootstrap -->
<link rel="stylesheet" href="<?php echo base_url('assets/cms_assets/vendors/bootstrap/dist/css/bootstrap.min.css'); ?>">
<!-- Font Awesome -->
<link rel="stylesheet" href="<?php echo base_url('assets/cms_assets/vendors/font-awesome/css/font-awesome.min.css'); ?>">

<!-- NProgress -->
<link rel="stylesheet" href="<?php echo base_url('assets/cms_assets/vendors/nprogress/nprogress.css'); ?>">

<!-- iCheck -->
<link rel="stylesheet" href="<?php echo base_url('assets/cms_assets/vendors/iCheck/skins/flat/green.css'); ?>">

<!-- bootstrap-progressbar -->
<link rel="stylesheet" href="<?php echo base_url('assets/cms_assets/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css'); ?>">

<!-- JQVMap -->
<link rel="stylesheet" href="<?php echo base_url('assets/cms_assets/vendors/jqvmap/dist/jqvmap.min.css'); ?>">

<!-- bootstrap-daterangepicker -->
<link rel="stylesheet" href="<?php echo base_url('assets/cms_assets/vendors/bootstrap-daterangepicker/daterangepicker.css'); ?>">

<!-- Custom Theme Style -->
<link rel="stylesheet" href="<?php echo base_url('assets/cms_assets/build/css/custom.min.css'); ?>">
