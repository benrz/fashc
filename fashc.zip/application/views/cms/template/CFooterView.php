<!-- footer content -->
<footer>
	<div class="pull-right">
		By Fashc
	</div>
	<div class="clearfix"></div>
</footer>
<!-- /footer content -->
